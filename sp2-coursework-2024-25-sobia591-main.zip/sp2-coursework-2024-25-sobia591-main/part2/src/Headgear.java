/**
 * Interface representing headgear with a method to computeable value.
 */
public interface Headgear {
    /**
     * Calculate the value of the headgear .
     *
     * 
     */
    double computeValue();
}
