/**
 * Class representing a bobble hat as a type of protective headgear.
 */
public class BobbleHat extends ProtectiveHeadgear {
    private double bobbleDiameter;

    /**
     * Constructor for BobbleHat.
     *
      protectionFactor 
      bobbleDiameter 
      IllegalArgumentException 
     */
    public BobbleHat(double protectionFactor, double bobbleDiameter) {
        super(protectionFactor);
        if (bobbleDiameter < 0) {
            throw new IllegalArgumentException("Bobble diameter cannot be negative.");
        }
        this.bobbleDiameter = bobbleDiameter;
    }

    /**
     * Gets the bobble diameter.
     *
     * return the bobble diameter.
     */
    public double getBobbleDiameter() {
        return bobbleDiameter;
    }

    
    public double computeValue() {
        return bobbleDiameter * 4 * getProtectionFactor();
    }

    @Override
    public String toString() {
        return "BobbleHat [BobbleDiameter: " + bobbleDiameter + ", Value: " + computeValue() + ", " + super.toString() + "]";
    }
}
