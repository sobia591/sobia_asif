/**
 * Class representing a scooter helmet as a type of protective headgear.
 */
public class ScooterHelmet extends ProtectiveHeadgear {
    private boolean hasVisor;

    
    public ScooterHelmet(double protectionFactor, boolean hasVisor) {
        super(protectionFactor);
        this.hasVisor = hasVisor;
    }
    public double computeValue() {
        int c1 = hasVisor ? 160 : 80;
        int c2 = 400;
        return c1 + getProtectionFactor() * c2;
    }


    public String toString() {
        return "ScooterHelmet [HasVisor: " + hasVisor + ", Value: " + computeValue() + ", " + super.toString() + "]";
    }
}

