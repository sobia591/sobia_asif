/**
 * Class representing a crown as a type of headgear.
 */
public class Crown implements Headgear {
    private int numberOfJewels;
    private static final int VALUE_FACTOR = 200000;

    /**
     * Constructor for Crown.
     
     */
    public Crown(int numberOfJewels) {
        if (numberOfJewels < 0) {
            throw new IllegalArgumentException("Number of jewels cannot be negative.");
        }
        this.numberOfJewels = numberOfJewels;
    }

    /**
     * Gets the number of jewels.
     *
     * return the number of jewels.
     */
    public int getNumberOfJewels() {
        return numberOfJewels;
    }

    /**
     * Sets the number of jewels.
    
     */


    
    public double computeValue() {
        return numberOfJewels * VALUE_FACTOR;
    }

    
    public String toString() {
        return "Crown [NumberOfJewels: " + numberOfJewels + ", Value: " + computeValue() + "]";
    }
}
