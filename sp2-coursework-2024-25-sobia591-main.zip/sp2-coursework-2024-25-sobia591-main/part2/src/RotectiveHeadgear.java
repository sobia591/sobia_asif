/**
 * Abstract class representing protective headgear.
 */
public abstract class ProtectiveHeadgear implements Headgear {
    private double protectionFactor;

    /**
     * Constructor for ProtectiveHeadgear.
     
     
      
     */
    public ProtectiveHeadgear(double protectionFactor) {
        if (protectionFactor < =0) {
            throw new IllegalArgumentException("Protection factor  not  negative.");
        }
        this.protectionFactor = protectionFactor;
    }

    /**
     * Gets the protection factor.
     *
     * return the protection factor.
     */
    public double getProtectionFactor() {
        return protectionFactor;
    }

    /**
     * Sets the protection factor.
     *
     *  protectionFactor the new protection factor
     *  IllegalArgumentException if the protection factor is negative.
     */
    public void setProtectionFactor(double protectionFactor) {
        if (protectionFactor < 0) {
            throw new IllegalArgumentException("Protection factor cannot be negative.");
        }
        this.protectionFactor = protectionFactor;
    }

    
    public String toString() {
        return "ProtectionFactor: " + protectionFactor;
    }
}
