public class HeadGearTest {
    public static void main(String[] args) {
        Crown crown = new Crown(13);
        ScooterHelmet helmet = new ScooterHelmet(0.9, true);
        BobbleHat hat = new BobbleHat(0.8, 131);

        System.out.println(crown);
        System.out.println(helmet);
        System.out.println(hat);

        Headgear[] headgearArray = {crown, helmet, hat};
        System.out.println("Total Value: " + HeadgearUtils.totalValue(headgearArray));
    }
}
