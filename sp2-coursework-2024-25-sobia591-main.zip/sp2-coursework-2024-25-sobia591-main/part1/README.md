Software and Programming 2
2024/25
Coursework Assignment 

Please enter your name here:
sobia asif



Please enter your Academic Declaration here:
“I have read and understood the sections of plagiarism in the College Policy on assessment offences and confirm that the work is my own, with the work of others clearly acknowledged. I give my permission to submit my report to the plagiarism testing database that the College is using and test it using plagiarism detection software, search engines or meta-searching software.”


